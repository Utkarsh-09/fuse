export { default } from './FuseShortcuts';
